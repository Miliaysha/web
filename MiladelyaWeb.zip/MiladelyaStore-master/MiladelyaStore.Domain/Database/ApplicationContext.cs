﻿using System.Net.Mime;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MiladelyaStore.Domain.Models;

namespace MiladelyaStore.Domain.Database;

public sealed class ApplicationContext : DbContext
{
    public ApplicationContext(DbContextOptions<ApplicationContext> options)
        : base(options)
    {
        Database.EnsureCreated();   // создаем базу данных при первом обращении
    }
    
    public DbSet<Admin> Admins { get; set; }
    public DbSet<Product> Products { get; set; }
    public DbSet<Order> Orders { get; set; }
    public DbSet<Client> Clients { get; set; }
}