﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MiladelyaStore.Domain.Models;

[Table("Clients")]
public class Client
{
    [Key]
    [Display(Name = "Логин")]
    [Column("login")]
    [StringLength(50)]
    public string? Login { get; set; }
    [Display(Name = "Пароль")]
    [Column("password")]
    public string Password { get; set; } = "";
    [Display(Name = "Фамилия")]
    [Column("lastname")]
    public string? LastName { get; set; }
    [Display(Name = "Имя")]
    [Column("name")]
    public string? Name { get; set; }
    [Display(Name = "Отчество")]
    [Column("patronymic")]
    public string? Patronymic { get; set; }
    [Display(Name = "Номер телефона")]
    [Column("phone")]
    [StringLength(50)]
    public string? Phone { get; set; }
    [Display(Name = "Электронная почта")]
    [Column("email")]
    public string? Email { get; set; }
}