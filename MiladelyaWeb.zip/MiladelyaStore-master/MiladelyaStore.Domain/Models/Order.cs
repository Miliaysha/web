﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MiladelyaStore.Domain.Models;

[Table("Orders")]
public class Order
{
    [Key]
    [Column("id")]
    [Display(Name = "Идентификатор")]
    public int Id { get; set; }
    [Display(Name = "Фамилия клиента")]
    [Column("client_lastname")]
    public string? LastName { get; set; }
    [Display(Name = "Имя клиента")]
    [Column("client_name")]
    public string? Name { get; set; }
    [Display(Name = "Отчество клиента")]
    [Column("client_patronymic")]
    public string? Patronymic { get; set; }
    [Display(Name = "Номер телефона клиента")]
    [Column("client_phone")]
    [StringLength(50)]
    public string? Phone { get; set; }
    [Display(Name = "Электронная почта клиента")]
    [Column("client_email")]
    public string? Email { get; set; }
    [Display(Name = "Идентификатор продукта")]
    [Column("productId")]
    public int ProductId { get; set; }
    [Display(Name = "Цена")]
    [Column("cost")]
    public float Cost { get; set; }
    [Display(Name = "Количество")]
    [Column("count")]
    public int Count { get; set; }
    [Display(Name = "Статус")]
    [Column("status")]
    [StringLength(50)]
    public string? Status { get; set; }

    [ForeignKey("ProductId")]
    public virtual Product Product { get; set; }
}