﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MiladelyaStore.Domain.Models;

[Table("Products")]
public class Product
{
    [Key]
    [Column("id")]
    [Display(Name = "Идентификатор")]
    public int Id { get; set; }
    [StringLength(50)]
    [Column("name")]
    [Display(Name = "Название продукта")]
    public string? ProductName { get; set; }
    [Display(Name = "Категория")]
    [Column("category")]
    public string? Category { get; set; }
    [Display(Name = "Цена")]
    [Column("cost")]
    public float Cost { get; set; }
    [Display(Name = "Изображение")]
    [Column("image")]
    public string? Image { get; set; }
}