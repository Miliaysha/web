﻿using System.Security.Claims;
using BeautySchool.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using MiladelyaStore.Domain.Database;
using MiladelyaStore.Domain.Models;

namespace MiladelyaStore.Controllers;

[Route("auth")]
public class AccountController : Controller
{
    private readonly ApplicationContext _context;

    public AccountController(ApplicationContext context)
    {
        _context = context;
    }

    [HttpGet]
    [AllowAnonymous]
    [Route("login")]
    public ActionResult Login([FromQuery] string returnUrl)
    {
        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login([FromForm] Admin adminFields, string? returnUrl)
    {
        if (!ModelState.IsValid)
            return RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel
                {
                    Message = "Введенные данные некорректны"
                });

        var admin = await _context.Admins
            .FirstOrDefaultAsync(u => u.Login == adminFields.Login && u.Password == adminFields.Password);

        var client = await _context.Clients
            .FirstOrDefaultAsync(u => u.Login == adminFields.Login && u.Password == adminFields.Password);

        var authClaims = new List<Claim>();
        switch (admin, client)
        {
            case (null, not null):
                authClaims = new List<Claim>
                {
                    new("login", Strings.Trim($"{client.Login}")),
                    new("role", Strings.Trim("client"))
                };
                break;
            case (not null, null):
                authClaims = new List<Claim>
                {
                    new("login", Strings.Trim($"{admin.Login}")),
                    new("role", Strings.Trim("admin"))
                };
                break;
            default:
                return RedirectToAction(
                    "Error",
                    "ErrorPage", new ErrorModel
                    {
                        Message = "Пользователь с введенными данными не найден"
                    }
                );
        }
        var claimsIdentity = new ClaimsIdentity(authClaims, "Cookies");
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(claimsIdentity));
        return Redirect(returnUrl ?? "/");
    }

    [HttpGet]
    [Authorize]
    [Route("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Redirect("/");
    }
}