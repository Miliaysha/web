﻿using BeautySchool.Models;
using Microsoft.AspNetCore.Mvc;

namespace MiladelyaStore.Controllers;

[Route("error")]
public class ErrorPageController : Controller
{
    [Route("")]
    public IActionResult Error(ErrorModel errorModel, Exception exception)
    {
        ViewBag.ErrorModel = errorModel;
        return View();
    }
}