﻿using Microsoft.AspNetCore.Mvc;
using MiladelyaStore.Domain.Database;

namespace MiladelyaStore.Controllers;

public class HomeController : Controller
{
    private readonly ApplicationContext _context;

    public HomeController(ApplicationContext context)
    {
        _context = context;
    }

    [Route("/")]
    public async Task<IActionResult> Index()
    {
        return View();
    }
    [Route("/About")]
    public async Task<IActionResult> About()
    {
        return View();
    }
}