﻿using BeautySchool.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiladelyaStore.Domain.Database;
using MiladelyaStore.Domain.Models;
using MiladelyaStore.Models;

namespace MiladelyaStore.Controllers;

[Route("/payment")]
public class PaymentController : Controller
{
    private readonly ApplicationContext _context;

    public PaymentController(ApplicationContext context)
    {
        _context = context;
    }

    [HttpGet]
    [AllowAnonymous]
    [Route("buy")]
    public async Task<IActionResult> GetPaymentForm([FromQuery]string returnUrl, [FromQuery]int productId)
    {
        var product = await _context.Products
            .FirstOrDefaultAsync(p => p.Id == productId);
        
        switch (product)
        {
            case null:
                return RedirectToAction(
                    "Error",
                    "ErrorPage",
                    new ErrorModel("Товар не найден"));
            default:
                ViewBag.ReturnUrl = returnUrl;
                ViewBag.Product = product;
                return View("Payment");
        }
    }

    [HttpPost]
    [AllowAnonymous]
    [Route("buy")]
    public async Task<IActionResult> BuyCourse([FromQuery]int productId, [FromQuery]string? returnUrl, PaymentDto paymentDto)
    {
        if (!ModelState.IsValid)
            return RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel("Неверные входные данные"));
        
        var product = await _context.Products
            .FirstOrDefaultAsync(p => p.Id == productId);
        
        if (product is null)
            return RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel("Товар не найден"));

        var order = new Order
        {
            LastName = paymentDto.LastName,
            Name = paymentDto.Name,
            Patronymic = paymentDto.Patronymic,
            Phone = paymentDto.Phone,
            Email = paymentDto.Email,
            ProductId = productId,
            Cost = product.Cost * paymentDto.Count,
            Count = paymentDto.Count,
            Status = "new"
        };

        await _context.Orders.AddAsync(order);

        return await _context.SaveChangesAsync() switch
        {
            0 => RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel("Произошла какая-то ошибка")),
            _ => Redirect(returnUrl ?? "/")
        };
    }
}