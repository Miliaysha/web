﻿using BeautySchool.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MiladelyaStore.Domain.Database;
using MiladelyaStore.Domain.Models;

namespace MiladelyaStore.Controllers;

[Route("/products")]
public class ProductsController : Controller
{
    private readonly ApplicationContext _context;

    public ProductsController(ApplicationContext context)
    {
        _context = context;
    }

    [HttpGet]
    [AllowAnonymous]
    [Route("")]
    public async Task<ActionResult> GetAll()
    {
        var products = _context.Products
            .OrderBy(p => p.Id);

        switch (await products.CountAsync())
        {
            case 0:
                return RedirectToAction(
                    "Error",
                    "ErrorPage", new ErrorModel
                    {
                        Message = "Товары не найдены"
                    });
            default:
                ViewBag.Title = "Все товары";
                ViewBag.Products = products;
                return View("Products");
        }
    }
    
    [HttpGet]
    [Authorize]
    [Route("create")]
    public ActionResult GetCreateForm()
    {
        return View("CreateProduct");
    }

    [HttpGet]
    [Authorize]
    [Route("edit/{id:int}")]
    public async Task<ActionResult> GetEditForm(int id)
    {
        var product = await _context.Products
            .FirstOrDefaultAsync(c => c.Id == id);
        if (product is null)
            return RedirectToAction(
                "Error",
                "ErrorPage",new ErrorModel
                {
                    Message = "Товар не найден"
                });
        ViewBag.Product = product;

        return View("EditProduct");
    }

    [HttpPost]
    [Authorize]
    [Route("create")]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> Post([FromForm] Product product)
    {
        if (!ModelState.IsValid)
            return View("CreateProduct");

        await _context.Products.AddAsync(product);

        return await _context.SaveChangesAsync() switch
        {
            0 => RedirectToAction("Error", "ErrorPage", new ErrorModel
            {
                Message = "Произошла какая-то ошибка"
            }),
            _ => new NoContentResult()
        };
    }

    [HttpPost]
    [Authorize]
    [Route("edit")]
    public async Task<ActionResult> Edit([FromForm] Product product)
    {
        var productToEdit = await _context.Products
            .FirstOrDefaultAsync(p => p.Id == product.Id);

        if (productToEdit is null)
            return RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel
                {
                    Message = "Товар не найден"
                });

        productToEdit.ProductName = product.ProductName ?? productToEdit.ProductName;
        productToEdit.Category = product.Category ?? productToEdit.Category;
        productToEdit.Cost = product.Cost == 0 ? productToEdit.Cost : product.Cost;
        productToEdit.Image = product.Image ?? productToEdit.Image;

        _context.Entry(productToEdit).State = EntityState.Modified;

        return await _context.SaveChangesAsync() switch
        {
            0 => RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel
                {
                    Message = "Произошла какая-то ошибка"
                }),
            _ => new NoContentResult()
        };
    }

    [HttpGet]
    [Authorize]
    [Route("delete/{id:int}")]
    public async Task<ActionResult> Delete(int id)
    {
        var product = await _context.Products
            .FirstOrDefaultAsync(p => p.Id == id);

        if (product is null)
            return RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel
                {
                    Message = "Товар не найден"
                });
        
        _context.Products.Remove(product);

        return await _context.SaveChangesAsync() switch
        {
            0 => RedirectToAction(
                "Error",
                "ErrorPage",
                new ErrorModel
                {
                    Message = "Произошла какая-то ошибка"
                }),
            _ => Redirect($"/products")
        };
    }
}