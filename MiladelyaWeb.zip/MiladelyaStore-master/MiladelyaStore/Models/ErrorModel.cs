﻿namespace BeautySchool.Models;

public class ErrorModel
{
    public string Message { get; set; }

    public ErrorModel()
    {
    }
    
    public ErrorModel(string message)
    {
        Message = message;
    }
}