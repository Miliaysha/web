﻿using System.ComponentModel.DataAnnotations;

namespace MiladelyaStore.Models;

public class PaymentDto
{
    [Display(Name = "Количество товаров")]
    [Range(1, 1000, ErrorMessage = "Значение должно быть в числовом формате!")]
    public int Count { get; set; }
    /// <summary>
    /// Checkbox confirmation
    /// </summary>
    [Display(Name = "Подтверждение оплаты")]
    [Range(typeof(bool), "true", "true", ErrorMessage = "Вы должны подтвердить оплату!")]
    public bool Confirmation { get; set; }
    [Display(Name = "Фамилия клиента")]
    public string? LastName { get; set; }
    [Display(Name = "Имя клиента")]
    public string? Name { get; set; }
    [Display(Name = "Отчество клиента")]
    public string? Patronymic { get; set; }
    [Display(Name = "Номер телефона клиента")]
    [StringLength(50)]
    public string? Phone { get; set; }
    [Display(Name = "Электронная почта клиента")]
    public string? Email { get; set; }
}